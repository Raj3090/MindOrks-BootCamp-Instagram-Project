package com.raj.sharephoto.ui.login

import androidx.lifecycle.ViewModel

open class LoginViewModel :ViewModel(){



}